# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Civitas
  module Estados_juego
		INICIO_TURNO = :inicio_turno  
		DESPUES_CARCEL = :despues_carcel
  	DESPUES_AVANZAR = :despues_avanzar
  	DESPUES_COMPRAR = :despues_comprar
  	DESPUES_GESTIONAR = :despues_gestionar
  end
end