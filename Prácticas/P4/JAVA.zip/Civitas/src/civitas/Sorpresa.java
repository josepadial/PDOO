/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;
import java.util.ArrayList;

/**
 *
 * @author Daniel
 */
public class Sorpresa {
    private String texto;
    private int valor;
    private TipoSorpresa tipo;
    private MazoSorpresas mazo;
    private Tablero tablero;
    private Diario diario = Diario.getInstance();
    
    Sorpresa(){
        init();
    }
    
    Sorpresa(TipoSorpresa tipo, Tablero tablero){
        init();
        this.tipo = tipo;
        this.tablero = tablero;
    }
    
    Sorpresa(TipoSorpresa tipo, Tablero tablero, int valor, String texto){
        init();
        this.tipo = tipo;
        this.tablero = tablero;
        this.valor = valor;
        this.texto = texto;
        
    }
    
    Sorpresa(TipoSorpresa tipo, MazoSorpresas mazo){
        init();
        this.tipo = tipo;
        this.mazo = mazo;
    }
    
    void aplicarJugador(int actual, ArrayList<Jugador> todos){
        
        if(tipo == TipoSorpresa.IRCARCEL){
            aplicarJugador_irCarcel(actual,todos);
        }
        else if(tipo == TipoSorpresa.IRCASILLA){
               aplicarJugador_irACasilla(actual,todos);
        }
        else if(tipo == TipoSorpresa.PAGARCOBRAR){
               aplicarJugador_pagarCobrar(actual,todos);
        }
        else if(tipo == TipoSorpresa.PORCASAHOTEL){
               aplicarJugador_porCasaHotel(actual,todos);
        }
        else if(tipo == TipoSorpresa.PORJUGADOR){
               aplicarJugador_porJugador(actual,todos);
        }
        else if(tipo == TipoSorpresa.SALIRCARCEL){
               aplicarJugador_salirCarcel(actual,todos);
        }
        
    }
    
    private void aplicarJugador_irACasilla(int actual, ArrayList<Jugador> todos){
        if(todos.get(actual) != null){
            informe(actual,todos);
            int numCasillaActual = todos.get(actual).getNumCasillaActual();
            int tirada = tablero.calcularTirada(numCasillaActual, valor);
            int newPos = tablero.nuevaPosicion(numCasillaActual, tirada);
            todos.get(actual).moverACasilla(newPos);
            tablero.getCasilla(valor).recibeJugador(actual, todos);
        }
    }
    
    private void aplicarJugador_irCarcel(int actual, ArrayList<Jugador> todos){
        if(todos.get(actual) != null){
            informe(actual,todos);
            todos.get(actual).encarcelar(tablero.getCarcel());
        }
    }
    
    private void aplicarJugador_pagarCobrar(int actual, ArrayList<Jugador> todos){
        if(todos.get(actual) != null){
            informe(actual,todos);
            todos.get(actual).modificarSaldo(valor);
        }
    }
    
    private void aplicarJugador_porCasaHotel(int actual, ArrayList<Jugador> todos){
        if(todos.get(actual) != null){
            informe(actual,todos);
            int numCasasHoteles = todos.get(actual).cantidadCasasHoteles();
            int importe = valor * numCasasHoteles;
            todos.get(actual).modificarSaldo(importe);
        }
    }
    
    private void aplicarJugador_porJugador(int actual, ArrayList<Jugador> todos){
        if(todos.get(actual) != null){
            informe(actual,todos);
            Sorpresa sorpresa = new Sorpresa(TipoSorpresa.PAGARCOBRAR,tablero,(valor * -1),"Jugadores Pagan");
           
            for(int i = 0; i < todos.size(); i++){
                if(todos.get(actual) != todos.get(i)){
                    sorpresa.aplicarJugador_pagarCobrar(i,todos);
                }
            }
            
            int numJug = todos.size() - 1;
            Sorpresa sorpresa2 = new Sorpresa(TipoSorpresa.PAGARCOBRAR,tablero,(valor * numJug),"Jugador recibe");
            sorpresa2.aplicarJugador_pagarCobrar(actual, todos);
        }
    }
    
    private void aplicarJugador_salirCarcel(int actual, ArrayList<Jugador> todos){
        boolean laTiene = false;
        
        if(todos.get(actual) != null){
            informe(actual,todos);
            for(int i = 0; i < todos.size(); i++){
                if(todos.get(i).tieneSalvoConducto() == true){
                    laTiene = true;
                }
            }
          
            if(laTiene == false){
                todos.get(actual).obtenerSalvoconducto(this);
                this.salirDelMazo();
            }
            
        }
    }
    
    private void informe(int actual, ArrayList<Jugador> todos){
        diario.ocurreEvento("Se aplica una sorpresa al jugador{" + todos.get(actual) + " de tipo{" + this.tipo +"} " );
    }
    
    private void init(){
        valor = -1;
        mazo = null;
        tablero = null;
        texto = "";
    }
    
    public boolean jugadorCorrecto(int actual, ArrayList<Jugador> todos){
        if(todos.get(actual)!= null){
            return true;
        }
        else{
            return false;
        }
    }
    
    void salirDelMazo(){
        if(this.tipo == TipoSorpresa.SALIRCARCEL){
            mazo.inhabilitarCartaEspecial(this);
        }
    }
    
    void usada(){
        if(this.tipo == TipoSorpresa.SALIRCARCEL){
            mazo.habilitarCartaEspecial(this);
        }
    }
    
    @Override
    public String toString(){
        return "Nombre de la carta {" + this.texto + " Valor " + this.valor + " Tipo " + this.tipo + " } ";
    }
    
    
}
    
