/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;
import java.util.ArrayList;
/**
 *
 * @author danielcruz16
 */
public class Casilla {
    private String nombre;
    private static int carcel;
    private float importe;
    MazoSorpresas mazo;
    TipoCasilla tipo;
    TituloPropiedad titulo;
    Sorpresa sorpresa;
    
    Casilla(String arg){
        init();
        this.nombre = arg;
        tipo = TipoCasilla.DESCANSO;
    }
    
    Casilla(TituloPropiedad titulo){
        init();
        this.nombre = titulo.getNombre();
        this.titulo = titulo;
        this.importe = titulo.getPrecioCompra();
        tipo = TipoCasilla.CALLE;
    }
    
    Casilla(String nombre, float cantidad){
        init();
        this.nombre = nombre;
        importe = cantidad;
        tipo = TipoCasilla.IMPUESTO;
    }
    
    Casilla(int numCasillaCarcel, String nombre){
        init();
        this.nombre = nombre;
        this.carcel = numCasillaCarcel;
        this.tipo = TipoCasilla.JUEZ;
    }
    
    Casilla(String nombre, MazoSorpresas mazo){
        init();
        this.nombre = nombre;
        tipo = TipoCasilla.SORPRESA;
        this.mazo = mazo;
        //Aqui deberia asociar la sorpresa de la casilla pero como lo hago
    }
    
    public String getNombre(){
        return nombre;
    }
    
    TituloPropiedad getTituloPropiedad(){
        return titulo;
    }
    
    private void informe(int actual, ArrayList<Jugador> todos){
        Diario diario = Diario.getInstance();
        diario.ocurreEvento("El jugador {" + todos.get(actual) +"} a caido en la casilla" + toString());
        toString();
    }
    
    private void init(){
        this.nombre = "Sin nombre";
        this.importe = 0;
        this.mazo = null;
        this.titulo = null;
        this.sorpresa = null;
    }
    
    public boolean jugadorCorrecto(int actual, ArrayList<Jugador> todos){
        if(todos.get(actual) != null){
            return true;
        }
        else{
            return false;
        }
    }
    
    void recibeJugador(int actual, ArrayList<Jugador> todos){
       if(tipo == TipoCasilla.CALLE){
           recibeJugador_calle(actual,todos);
       }
       else if(tipo == TipoCasilla.IMPUESTO){
           recibeJugador_impuesto(actual,todos);
       }
       else if(tipo == TipoCasilla.JUEZ){
           recibeJugador_juez(actual,todos);
       }
       else if(tipo == TipoCasilla.SORPRESA){
           recibeJugador_sorpresa(actual,todos);
       }
       else{
           informe(actual,todos);
       }
    }
    private void recibeJugador_calle(int actual, ArrayList<Jugador> todos){
        if(jugadorCorrecto(actual,todos) == true){
            informe(actual,todos);
            if(titulo.tienePropietario() == false){
                todos.get(actual).puedeComprarCasilla();
            }
            else{
                titulo.tramitarAlquiler(todos.get(actual));
            }
        }
    }
    
    private void recibeJugador_impuesto(int actual, ArrayList<Jugador> todos){
        if(jugadorCorrecto(actual,todos) == true){
            informe(actual,todos);
            todos.get(actual).pagaImpuesto(importe);
        }
    }
    
    private void recibeJugador_juez(int actual, ArrayList<Jugador> todos){
        if(jugadorCorrecto(actual,todos) == true){
            informe(actual,todos);
            todos.get(actual).encarcelar(carcel);
        }
    }
    
    private void recibeJugador_sorpresa(int actual, ArrayList<Jugador> todos){
        if(jugadorCorrecto(actual,todos) == true){
            Sorpresa sorpresa = mazo.siguiente();
            informe(actual,todos);
            sorpresa.aplicarJugador(actual, todos);
        }
    }
    
    public String toString(){
       return "Casilla{" + "nombre=" + nombre + ", importe=" + importe + ", tipo=" + tipo + ", titulo=" + titulo + ", sorpresa=" + sorpresa + "}";
    }
}
