# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative"mazo_sorpresas.rb"
require_relative"tipo_casilla.rb"
require_relative"titulo_propiedad.rb"
require_relative"sorpresa.rb"
require_relative"diario.rb"

module Civitas
  class Casilla
    
    def initialize(nombre, importe, mazo, titulo, sorpresa, tipo, carcel)
      @nombre = nombre
      @importe = importe
      @mazo = mazo
      @titulo = titulo
      @sorpresa = sorpresa
      @tipo = tipo
      @carcel = carcel
      @diario = Diario.instance
    end
    
    def self.init_descanso(nombre)
      new(nombre,0,nil,nil,nil,Tipo_casilla::DESCANSO,nil)
    end
    
    def self.init_calle(titulo)
      new(titulo.get_nombre,titulo.get_precio_compra,nil,titulo,nil,Tipo_casilla::CALLE,nil)
    end
    
    def self.init_impuesto(cantidad, nombre)
      new(nombre,cantidad,nil,nil,nil,Tipo_casilla::IMPUESTO,nil)
    end
    
    def self.init_juez(num_casilla_carcel,nombre)
      new(nombre,0,nil,nil,nil,Tipo_casilla::JUEZ,num_casilla_carcel)
    end
    
    def self.init_sorpresa(nombre,mazo)
      new(nombre,0,mazo,nil,nil,Tipo_casilla::SORPRESA,nil)
    end
    
    private
    
    def informe(actual, todos)
      @diario.ocurre_evento("El jugador " + todos.at(actual).get_nombre + " ha caido en la casilla " + to_s)
    end
   
     public 
    def get_nombre
      @nombre
    end
    
    def get_titulo_propiedad
      @titulo
    end
    
    def jugador_correcto(actual,todos)
      if(todos.at(actual) != nil)
            return true
        else
            return false
      end
    end
    
    def recibe_jugador_impuestos(actual,todos)
      if(jugador_correcto(actual,todos))
        informe(actual, todos)
        todos[actual].paga_impuestos(@importe)
      end
    end
    
    def recibe_jugador_juez(actual,todos)
      if(jugador_correcto(actual,todos))
        informe(actual, todos)
        todos[actual].encarcelar(@carcel)
      end
    end
    
    def recibe_jugador_sorpresa(actual,todos)
      if(jugador_correcto(actual,todos) == true)
        sorpresa = @mazo.siguiente
        informe(actual,todos)
        sorpresa.aplicar_a_jugador(actual, todos)
      end
    end
    
    def recibe_jugador(actual,todos)
      if(@tipo == Tipo_casilla::CALLE)
           recibe_jugador_calle(actual,todos)
      end
      
      if(@tipo == Tipo_casilla::IMPUESTO)
           recibe_jugador_impuesto(actual,todos)
      end
      
      if(@tipo == Tipo_casilla::JUEZ)
           recibe_jugador_juez(actual,todos)
      end
      
      if(@tipo == Tipo_casilla::SORPRESA)
           recibe_jugador_sorpresa(actual,todos)
      else
           informe(actual,todos)
      end
    end
    
    def recibe_jugador_calle(actual,todos)
      if(jugador_correcto(actual,todos) == true)
        informe(actual,todos);
        
        if(@titulo.tiene_propietario == false)
          todos.at(actual).puede_comprar_casilla
        else
          @titulo.tramitar_alquiler(todos.at(actual))
        end
        
      end
    end
    
    def to_s
      to_s="Nombre #{@nombre}"
    end

  end
end
