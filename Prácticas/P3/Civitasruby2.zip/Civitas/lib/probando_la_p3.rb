# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "civitas_juego.rb"
require_relative "dado.rb"
require_relative "diario.rb"

module Modulo_Probando_la_P3
  class Probando_la_P3
    def self.main_P3
      @@dado = Civitas::Dado.instance 
      @@dado.set_debug(true)
      @@diario = Civitas::Diario.instance
      
      @nombres = Array.new()
      @nombres << "Woody"
      @nombres << "Buzz"
      
      @juego = Civitas::Civitas_juego.new(@nombres)
      
      @@diario.ocurre_evento("Empieza el turno del jugador #{@juego.get_jugador_actual.get_nombre} \n")
      @juego.avanza_jugador
      @juego.comprar()
      for i in 0 .. 4
        @juego.construir_casa(0)
      end
      
      @juego.construir_hotel(0)
      @juego.construir_hotel(0)
      
      @juego.pasar_turno
      
      @@diario.ocurre_evento("Empieza el turno del jugador #{@juego.get_jugador_actual.get_nombre} \n")
      
      @juego.avanza_jugador
      @juego.construir_casa(0)
      
      @@diario.ocurre_evento("Info de jugador 2 #{@juego.info_jugador_texto} \n")
     
      @juego.pasar_turno
      
      @@diario.ocurre_evento("Empieza el turno del jugador #{@juego.get_jugador_actual.get_nombre} \n")
      
      @@diario.ocurre_evento("Info de jugador 1 #{@juego.info_jugador_texto} \n")
      
      while(@@diario.eventos_pendientes == true)
        puts @@diario.leer_evento
      end
    end
  end
  Probando_la_P3.main_P3
end

