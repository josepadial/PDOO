# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "tablero.rb"
require_relative "diario.rb"
require_relative "tipo_sorpresa.rb"
require_relative "jugador.rb"
require_relative "mazo_sorpresas.rb"

module Civitas
class Sorpresa
  
    def initialize(valor,mazo,tablero,texto,tipo)
      @valor = valor
      @mazo = mazo
      @tablero = tablero
      @texto = texto
      @tipo = tipo
      @diario = Diario.instance
    end
  
    def self.init_carcel(tipo,tablero)
      new(0,nil,tablero,"",tipo)
    end
    
    def self.init_otra(tipo,tablero,valor,texto)
      new(valor,nil,tablero,texto,tipo,)
    end
    
    def self.init_sorpresa(tipo,mazo)
      new(0,mazo,nil,"",tipo)
    end
    
    private
    
    def aplicar_a_jugador_ir_a_casilla(actual,todos)
      if(jugador_correcto(actual,todos))
        informe(actual,todos)
        casilla_actual = todos[actual].get_num_casilla_actual
        tirada = @tablero.calcular_tirada(casilla_actual, @valor)
        new_pos = @tablero.nueva_posicion(casilla_actual, tirada)
        todos[actual].mover_a_casilla(new_pos)
        @tablero.get_casilla(new_pos).recibe_jugador(actual,todos)
      end
    end
    
    def aplicar_a_jugador_ir_carcel(actual,todos)
      if(jugador_correcto(actual,todos))
        informe(actual,todos)
        todos[actual].encarcelar(@tablero.get_carcel)
      end
    end
    
    public
    def aplicar_a_jugador_pagar_cobrar(actual,todos)
      if(jugador_correcto(actual,todos))
        informe(actual,todos)
        todos[actual].modificar_saldo(@valor)
      end
    end
    
    private
    def aplicar_a_jugador_por_casa_hotel(actual,todos)
      if(jugador_correcto(actual,todos))
        informe(actual,todos)
        num_casas_hoteles = todos[actual].cantidad_casas_hoteles
        importe = @valor*num_casas_hoteles
        todos[actual].modificar_saldo(importe)
      end
    end
    
    def aplicar_a_jugador_por_jugador(actual,todos)
      if(jugador_correcto(actual,todos))
        informe(actual,todos)
        sorpresa = Sorpresa.new((@valor*-1),nil,@tablero,"Jugadores pagan",Tipo_sorpresa::PAGARCOBRAR)
        
        for i in (0..todos.length)
          if(todos.at(i) != todos[actual])
            sorpresa.aplicar_a_jugador_pagar_cobrar(i,todos)
          end
        end
        
        num_jugadores = todos.length - 1
        
        sorpresa2 = Sorpresa.new((@valor * num_jugadores),nil,@tablero, "Jugador actual recibe",Tipo_sorpresa::PAGARCOBRAR)
        sorpresa2.aplicar_a_jugador_pagar_cobrar(actual,todos)
      end
      
    end
    
    def aplicar_a_jugador_salir_carcel(actual,todos)
      
      la_tiene = false
      
      if(todos[actual] != nil)
        informe(actual,todos)
        for i in todos
          if(i.tiene_salvo_conducto == true)
            la_tiene = true
          end
        end
        
        if(la_tiene == false)
          todos[actual].obtener_salvo_conducto(self)
          salir_del_mazo
        end
        
      end
      
    end
    
    def informe(actual,todos)
      @diario.ocurre_evento("Se aplica una sorpresa al jugador" + todos.at(actual).get_nombre + " de tipo " + @tipo.to_s)
    end
  
  public
    def aplicar_a_jugador(actual,todos)
      case @tipo
        when Tipo_sorpresa::IRACARCEL
          aplicar_a_jugador_ir_carcel(actual,todos)
        when Tipo_sorpresa::IRACASILLA
          aplicar_a_jugador_ir_a_casilla(actual,todos)
        when Tipo_sorpresa::PAGARCOBRAR
          aplicar_a_jugador_pagar_cobrar(actual,todos)
        when Tipo_sorpresa::PORCASAHOTEL
          aplicar_a_jugador_por_casa_hotel(actual,todos)
        when Tipo_sorpresa::PORJUGADOR
          aplicar_a_jugador_por_jugador(actual,todos)
        when Tipo_sorpresa::SALIRCARCEL
          aplicar_a_jugador_salir_carcel(actual,todos)
      end
      
    end
    
    def jugador_correcto(actual,todos)
      if(todos.at(actual) != nil)
        return true
      else
        return false
      end
    end
    
    def salir_del_mazo()
      if(@tipo == Tipo_sorpresa::SALIRCARCEL)
        @mazo.inhabilitar_carta_especial(self)
      end
    end
    
    def usadas()
      if(@tipo == Tipo_sorpresa::SALIRCARCEL)
        @mazo.habilitar_carta_especial(self)
      end
    end
    
    def to_s
      to_s="Nombre de la carta {#{@texto}, valor=#{@valor}, tipo=#{@tipo}}"
    end
    
end
end